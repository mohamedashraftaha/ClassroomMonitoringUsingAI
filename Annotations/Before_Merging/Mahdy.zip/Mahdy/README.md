Description

This repo consists of the labelled bounded boxes of our generated dataset


Tool used
labelimg
